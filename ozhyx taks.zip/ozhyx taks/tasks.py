
import datetime

# dicionario de lembretes

def add_task():
    data_str = input("Digite a data e a hora da tarefa (formato: DD/MM/YYYY HH:MM): ")
    data_hora = datetime.datetime.strptime(data_str, "%d/%Y %H:%M")
    descricao = input("Digite a descrição da tarefa")
    tasks[data_hora] = descricao
    print( "Tarefa adicionada !")

def list_tasks():
    for data_hora , descricao in sorted(tasks.items()):
        print(f"{data_hora.strftime('%d/%m/%Y %H:%M')} - {descricao}")
    try:
        data_hora = datetime.datetime.strptime(data_str,"%d/%m/%Y %H:%M")
        if data_hora in tasks:
            del tasks[data_hora]
            print("task removida !")
        else:
            print("task não encontrada :/")
    except ValueError:
        print("Formato de data e hora inválido.")

    while True:
        print("\nOpções:")
        print("1.Adicionar Task")
        print("2. Listar tasks")
        print("3. Remover lembrete")
        print("4. Sair")

        escolha = input("Escolha uma das opções: ")
        
        if escolha =='1':
            adicionar_task()

        elif escolha == '2':
            listar_task() 

        elif escolha == '3':
              remover_task()

        elif escolha == '4':
              print("saindo do zhyx tasks")
        break