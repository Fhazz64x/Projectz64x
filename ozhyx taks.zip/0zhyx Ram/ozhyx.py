import psutil
import tkinter as tk
from tkinter import messagebox
import threading

#Otimizar a RAM

def optimize_ram():
    try:
        psutil.virtual_memory().available
    except Exception as e:
        messagebox.showerror("Erro", "Não foi possível acessar informações de RAM")
        return
    
    #lógica de otimização de RAM
    #(subistituindo a logica realde otimização)

    #liberar mais memória em cache

    messagebox.showinfo("Prontinho !" "A otimizãção da RAM está completa ! ^.^")

    #função janela

def hide_window():
        root.iconify()

        #janela tkinter


root = tk.Tk()
root.title("Ozhyx RAM")
root.geometry("300x100")

#butão de otimizar

optimize_button = tk.Button(root,text="Otimizar RAM", command=optimize_ram)
optimize_button.pack(pady=10)

#botão de fechar a janela
hide_button = tk.Button(root,text="Fechar", command=hide_window)

#abrir janela com thread separada 

window_thread = threading.Thread(target=root.mainloop)
window_thread.start()


    