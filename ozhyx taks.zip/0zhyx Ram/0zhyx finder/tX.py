def check_robots_txt(url):
    try:
        response = requests.get(f"{url}/robots.txt")