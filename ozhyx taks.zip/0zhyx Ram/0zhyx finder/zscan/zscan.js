const Discord = require('discord.js');
const bot = new Discord.Client();
const token = 'MTA4NzgyMTUzMDQ3OTcyMjU2Ng.GJkaVC.7_Jo4GL1vQ8qkrfTtCvgT8TiV7XmUmnaVPWvIw'; // Substitua pelo seu próprio token de bot

// Importa a biblioteca de enumeração de subdomínios
const SubdomainEnum = require('subdomain-enumeration');

const prefix = '!'; // Prefixo dos comandos do bot
const subdomainEnum = new SubdomainEnum();

bot.on('ready', () => {
  console.log(`Bot conectado como ${bot.user.tag}`);
});

bot.on('message', async (message) => {
  if (message.author.bot) return; // Ignora mensagens de outros bots
  if (!message.content.startsWith(prefix)) return; // Verifica se a mensagem começa com o prefixo

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'findsubs') {
    if (args.length === 0) {
      message.channel.send('Uso incorreto. Use !findsubs [domínio]');
      return;
    }

    const domain = args[0];

    try {
      const subdomains = await subdomainEnum.getSubdomains(domain);
      if (subdomains.length > 0) {
        message.channel.send(`Subdomínios encontrados para ${domain}:\n${subdomains.join('\n')}`);
      } else {
        message.channel.send(`Nenhum subdomínio encontrado para ${domain}.`);
      }
    } catch (error) {
      console.error('Erro ao buscar subdomínios:', error);
      message.channel.send('Ocorreu um erro ao buscar subdomínios.');
    }
  }
});

bot.login(token);
