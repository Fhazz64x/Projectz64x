import requests

#verificara  existencia do arquivo robots.txt

def check_robots_txt(url):
    try:
        response = requests.get(f"{url}/robots.txt", timeout=5)
        return True
    except requests.exceptions.RequestException:
        pass
    return False
if __name__== "__main__":
    terget_url = input("Digite a URL: ")

    if check_robots_txt(target_url):
        print("O arquivo robots.txt foi encontrado.temos um sinal...")
    else:
        print("O arquivo robots.txt não foi encontrado . total de 0")
