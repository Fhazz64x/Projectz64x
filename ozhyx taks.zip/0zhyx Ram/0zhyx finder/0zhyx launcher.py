import os
import sys

# Função para listar os projetos disponíveis
def listar_projetos():
    projetos = [d for d in os.listdir() if os.path.isdir(d) and os.path.exists(os.path.join(d, 'main.py'))]
    return projetos

# Função para exibir a lista de projetos
def exibir_lista_projetos():
    print("Projetos disponíveis:")
    projetos = listar_projetos()
    for i, projeto in enumerate(projetos, start=1):
        print(f"{i}. {projeto}")

# Função para selecionar e executar um projeto
def executar_projeto(projeto):
    try:
        os.chdir(projeto)
        exec(open("main.py").read())
    except Exception as e:
        print(f"Erro ao executar o projeto: {e}")
    finally:
        os.chdir("..")

if __name__ == "__main__":
    while True:
        exibir_lista_projetos()
        escolha = input("Digite o número do projeto que deseja executar (ou 'q' para sair): ")
        
        if escolha.lower() == 'q':
            sys.exit(0)
        
        try:
            escolha = int(escolha)
            projetos = listar_projetos()
            if 1 <= escolha <= len(projetos):
                projeto_selecionado = projetos[escolha - 1]
                executar_projeto(projeto_selecionado)
            else:
                print("Escolha inválida. Tente novamente.")
        except ValueError:
            print("Escolha inválida. Tente novamente.")
