import requests

#dominio que deseja usar
domain = input("Digite o domínio principal (exemplo.com): ")

#lista de subdominios encontrados
subdomains = []

#Carregue uma lista de palavras-chave para pesquisa (você pode usar uma lista longa fique avontade ^.^)
wordlist =[
    "www",
    "blog",
    "admin",
    "test",

]

#verifica a existencia de um subdomínio

def check_subdomain(subdomain):
    url = f"http://{subdomain}.{domain}"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return True
    except requests.exceptions.RequestException:
        pass
    return False


#varre os subdomínios suando a lista que você selecionou

for word in wordlist:
    subdomain = f"{word}.{domain}"
    if check_subdomain(subdomain):
        subdomains.append(subdomain)
        
#subdomínios encontrados

if subdomains:
    print("Subdomínios encontrados:")
    for subdomain in subdomains:
        print(subdomain)
    
else:
    print("Nenhum subdomínio encontrado.")