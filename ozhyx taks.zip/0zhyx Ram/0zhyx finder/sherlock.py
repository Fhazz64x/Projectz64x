import discord
from discord.ext import commands
import sublist3r

# Configurações do bot
prefix = "!"  # Prefixo dos comandos do bot
token = "MTA4NzgyMTUzMDQ3OTcyMjU2Ng.GJkaVC.7_Jo4GL1vQ8qkrfTtCvgT8TiV7XmUmnaVPWvIw"  # Substitua pelo seu próprio token de bot

intents = discord.Intents.default()
intents.typing = False 
intents.presences = False
# Inicializa o bot
bot = commands.Bot(command_prefix=prefix,intents=intents)

# Comando para encontrar subdomínios
@bot.command()
async def findsubs(ctx, domain):
    await ctx.send(f"Procurando subdomínios para {domain}...")
    subdomains = sublist3r.main(domain, 40, 'Sublist3r/sublist3r.py')
    if subdomains:
        await ctx.send(f"Subdomínios encontrados para {domain}:\n" + "\n".join(subdomains))
    else:
        await ctx.send(f"Nenhum subdomínio encontrado para {domain}.")

# Evento de inicialização do bot
@bot.event
async def on_ready():
    print(f"Bot conectado como {bot.user.name}")

# Inicializa o bot
bot.run(token)
